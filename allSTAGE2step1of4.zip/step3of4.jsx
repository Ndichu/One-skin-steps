const Step3of4 = () => {
  return <div className="div">
  <div className="div-2">
    <div className="div-3">
      <div className="div-4">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/90b5f91e5d8c47791a7247d6730ffff83ecd04b34ec883f056ece38595bb88c1?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
          className="img"
        />
        <div className="div-5">Back</div>
      </div>
      <div className="div-6">Take Your Skin Quiz</div>
    </div>
    <div className="div-7">
      <div className="div-8">
        <div className="div-9">Step 3 of 4</div>
        <div className="div-10">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/aa8c1b30e57e2b1d3ead25465c75acc8d7216b7af05384b8e7a724573596c997?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
            className="img-2"
          />
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/aa8c1b30e57e2b1d3ead25465c75acc8d7216b7af05384b8e7a724573596c997?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
            className="img-3"
          />
          <div className="div-11">
            <div className="div-12" />
          </div>
          <div className="div-13" />
        </div>
      </div>
    </div>
    <div className="div-14">
      We are almost there. Name your formula and select your preferred color and
      fragrance
    </div>
    <div className="div-15">Your Name or Nick Name</div>
    <input type="text" className="input-16" placeholder="Peter" />
    <div className="div-17">Only use numbers or letters</div>
    <input type="text" className="input-18" placeholder="Your email address" />
    <div className="div-19">
      We will use this to save your formula for easy access next time
    </div>
    <div className="div-21">Only use numbers or letters</div>
    <img
      loading="lazy"
      srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/0c7b17ec8cb25a73c785a8b2ff7d9776be418d398783ebdd7599d453b8d7f37d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
      className="img-4"
    />
    <div className="div-22">What color do you want?</div>
    <div className="div-23">
      <div className="div-24">
        <div className="div-25" />
        <div className="div-26">Blue</div>
      </div>
      <div className="div-27">
        <div className="div-28" />
        <div className="div-29">Green</div>
      </div>
      <div className="div-30">
        <div className="div-31" />
        <div className="div-32">Red</div>
      </div>
      <div className="div-33">
        <div className="div-34" />
        <div className="div-35">Black</div>
      </div>
    </div>
    <div className="div-36">What fragrance do you want?</div>
    <div className="div-37">
      <div className="div-38">
        <img
          loading="lazy"
          srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/3e1f263d97957843c88b7790f81d868a5e0d07341a6f33afcbe67c1c360ddadf?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
          className="img-5"
        />
        <div className="div-39">Strawberry</div>
      </div>
      <div className="div-40">
        <img
          loading="lazy"
          srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/a7082d535ad421aa75bd5c359ad6f78b3118d659efb1c4695bef12228907917e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
          className="img-6"
        />
        <div className="div-41">Blueberry</div>
      </div>
      <div className="div-42">
        <img
          loading="lazy"
          srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/d0d8e6599268feb664b4c455f7def327d1f72db274ddab37d1c1d9d75160f56d?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
          className="img-7"
        />
        <div className="div-43">Vanilla</div>
      </div>
    </div>
    <div className="div-44">
      <div className="div-45">Back</div>
      <div className="div-46">Next</div>
    </div>
  </div>
</div>;
};
export default Step3of4;
  
  <style>
    .div {
      padding-top: 16px;
      align-items: center;
      display: flex;
      flex-direction: column;
    }
    .div-2 {
      align-items: flex-start;
      border-radius: 8px;
      background-color: #fff;
      display: flex;
      width: 662px;
      max-width: 100%;
      flex-direction: column;
      padding: 24px 0 24px 24px;
    }
    @media (max-width: 991px) {
      .div-2 {
        padding-left: 20px;
      }
    }
    .div-3 {
      justify-content: space-between;
      align-items: center;
      align-self: stretch;
      display: flex;
      gap: 20px;
    }
    @media (max-width: 991px) {
      .div-3 {
        max-width: 100%;
        flex-wrap: wrap;
      }
    }
    .div-4 {
      border-radius: 6px;
      display: flex;
      gap: 4px;
      margin: auto 0;
      padding: 0 1px;
    }
    .img {
      aspect-ratio: 0.8;
      object-fit: contain;
      object-position: center;
      width: 16px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-5 {
      color: var(--TextColor, #333);
      flex-grow: 1;
      white-space: nowrap;
      font: 500 14px/143% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-5 {
        white-space: initial;
      }
    }
    .div-6 {
      color: var(--TextColor, #333);
      text-align: center;
      align-self: stretch;
      flex-grow: 1;
      white-space: nowrap;
      font: 500 18px/27px Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-6 {
        max-width: 100%;
        white-space: initial;
      }
    }
    .div-7 {
      justify-content: center;
      align-items: center;
      align-self: stretch;
      display: flex;
      margin-top: 16px;
      flex-direction: column;
      padding: 10px 60px;
    }
    @media (max-width: 991px) {
      .div-7 {
        max-width: 100%;
        padding: 0 20px;
      }
    }
    .div-8 {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
    }
    .div-9 {
      color: var(--gray-900, #111827);
      margin: auto 0;
      font: 500 14px/114% Montserrat, sans-serif;
    }
    .div-10 {
      align-items: flex-start;
      align-self: stretch;
      display: flex;
      padding-right: 6px;
      gap: 17px;
    }
    @media (max-width: 991px) {
      .div-10 {
        justify-content: center;
      }
    }
    .img-2 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      align-self: stretch;
      max-width: 100%;
    }
    .img-3 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      align-self: stretch;
      max-width: 100%;
    }
    .div-11 {
      border-radius: 50%;
      background-color: #d5f6e7;
      align-self: stretch;
      display: flex;
      aspect-ratio: 1.2;
      flex-direction: column;
      justify-content: center;
      padding: 2px 4px;
    }
    .div-12 {
      border-radius: 50%;
      background-color: var(--Green, #24a86a);
      display: flex;
      height: 16px;
      flex-direction: column;
    }
    .div-13 {
      border-radius: 100px;
      background-color: var(--gray-200, #e5e7eb);
      align-self: center;
      display: flex;
      width: 16px;
      height: 16px;
      flex-direction: column;
      margin: auto 0;
    }
    .div-14 {
      align-self: stretch;
      color: var(--TextColor, #333);
      margin-top: 16px;
      font: 500 16px/24px Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-14 {
        max-width: 100%;
      }
    }
    .div-15 {
      color: var(--gray-700, #374151);
      align-self: stretch;
      margin-top: 16px;
      font: 500 14px/143% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-15 {
        max-width: 100%;
      }
    }
    .input-16 {
      color: var(--gray-900, #111827);
      white-space: nowrap;
      align-items: start;
      align-self: stretch;
      border-radius: 6px;
      border: 1px solid var(--gray-300, #d1d5db);
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
      background-color: var(--white, #fff);
      margin-top: 8px;
      justify-content: center;
      padding: 9px 60px 9px 13px;
      font: 400 14px/143% Montserrat, sans-serif;
    }
    
    @media (max-width: 991px) {
      .input-16 {
        white-space: initial;
        max-width: 100%;
        padding-right: 20px;
      }
    }
    
    .input-18 {
      color: var(--gray-900, #111827);
      white-space: nowrap;
      align-items: start;
      align-self: stretch;
      border-radius: 6px;
      border: 1px solid var(--gray-300, #d1d5db);
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
      background-color: var(--white, #fff);
      margin-top: 8px;
      justify-content: center;
      padding: 9px 60px 9px 13px;
      font: 400 14px/143% Montserrat, sans-serif;
    }
    
    @media (max-width: 991px) {
      .input-18 {
        max-width: 100%;
        white-space: initial;
        padding-right: 20px;

      }
    }
    
    .div-17 {
      color: var(--Green, #24a86a);
      align-self: stretch;
      margin-top: 8px;
      font: italic 400 14px/143% Montserrat, -apple-system, Roboto, Helvetica,
        sans-serif;
    }
    @media (max-width: 991px) {
      .div-17 {
        max-width: 100%;
      }
    }
    
    .div-19 {
      color: var(--Green, #24a86a);
      align-self: stretch;
      margin-top: 8px;
      font: italic 400 12px/20px Montserrat, -apple-system, Roboto, Helvetica,
        sans-serif;
    }
    @media (max-width: 991px) {
      .div-19 {
        max-width: 100%;
      }
    }
    .div-20 {
      color: var(--gray-900, #111827);
      white-space: nowrap;
      align-items: start;
      align-self: stretch;
      border-radius: 6px;
      border: 1px solid var(--gray-300, #d1d5db);
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
      background-color: var(--white, #fff);
      margin-top: 8px;
      justify-content: center;
      padding: 9px 60px 9px 13px;
      font: 400 14px/143% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-20 {
        white-space: initial;
        max-width: 100%;
        padding-right: 20px;
      }
    }
    .div-21 {
      color: var(--Green, #24a86a);
      align-self: stretch;
      margin-top: 8px;
      font: italic 400 14px/143% Montserrat, -apple-system, Roboto, Helvetica,
        sans-serif;
    }
    @media (max-width: 991px) {
      .div-21 {
        max-width: 100%;
      }
    }
    .img-4 {
      aspect-ratio: 3.35;
      object-fit: contain;
      object-position: center;
      width: 382px;
      overflow: hidden;
      align-self: start;
      margin-top: 16px;
      max-width: 100%;
    }
    .div-22 {
      align-self: stretch;
      color: var(--Green, #24a86a);
      margin-top: 16px;
      font: 500 16px/24px Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-22 {
        max-width: 100%;
      }
    }
    .div-23 {
      align-items: flex-start;
      align-self: start;
      display: flex;
      margin-top: 16px;
      justify-content: space-between;
      gap: 20px;
    }
    @media (max-width: 991px) {
      .div-23 {
        justify-content: center;
      }
    }
    .div-24 {
      align-self: start;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
      padding: 8px;
    }
    .div-25 {
      border-radius: 50%;
      display: flex;
      height: 40px;
      flex-direction: column;
      background-color: blue;
    }
    .div-26 {
      color: var(--TextColor, #333);
      text-align: center;
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-26 {
        white-space: initial;
      }
    }
    .div-27 {
      align-self: stretch;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
      padding: 8px;
    }
    .div-28 {
      border-radius: 50%;
      display: flex;
      height: 40px;
      flex-direction: column;
      background-color: green;
    }
    .div-29 {
      color: var(--TextColor, #333);
      text-align: center;
      margin-top: 8px;
      font: 500 16px/24px Montserrat, sans-serif;
    }
    .div-30 {
      align-self: start;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
      padding: 8px;
    }
    .div-31 {
      border-radius: 50%;
      display: flex;
      height: 40px;
      flex-direction: column;
      background-color: red;
    }
    .div-32 {
      color: var(--TextColor, #333);
      text-align: center;
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-32 {
        white-space: initial;
      }
    }
    .div-33 {
      align-self: start;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
      padding: 8px;
    }
    .div-34 {
      border-radius: 50%;
      display: flex;
      height: 40px;
      flex-direction: column;
      background-color: black;
    }
    .div-35 {
      color: var(--TextColor, #333);
      text-align: center;
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-35 {
        white-space: initial;
      }
    }
    .div-36 {
      align-self: stretch;
      color: var(--Green, #24a86a);
      margin-top: 16px;
      white-space: nowrap;
      font: 500 16px/24px Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-36 {
        max-width: 100%;
        white-space: initial;
      }
    }
    .div-37 {
      align-self: start;
      display: flex;
      margin-top: 16px;
      width: 388px;
      max-width: 100%;
      justify-content: space-between;
      gap: 20px;
    }
    @media (max-width: 991px) {
      .div-37 {
        justify-content: center;
      }
    }
    .div-38 {
      padding-bottom: 8px;
      align-items: center;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
    }
    .img-5 {
      aspect-ratio: 1.21;
      object-fit: contain;
      object-position: center;
      width: 93px;
      overflow: hidden;
    }
    .div-39 {
      color: var(--TextColor, #333);
      align-self: stretch;
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/125% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-39 {
        white-space: initial;
      }
    }
    .div-40 {
      padding-bottom: 8px;
      align-items: center;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
    }
    .img-6 {
      aspect-ratio: 1.19;
      object-fit: contain;
      object-position: center;
      width: 92px;
      overflow: hidden;
    }
    .div-41 {
      color: var(--TextColor, #333);
      align-self: stretch;
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/125% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-41 {
        white-space: initial;
      }
    }
    .div-42 {
      padding-bottom: 8px;
      align-items: center;
      display: flex;
      flex-grow: 1;
      flex-basis: 0%;
      flex-direction: column;
    }
    .img-7 {
      aspect-ratio: 1.21;
      object-fit: contain;
      object-position: center;
      width: 93px;
      overflow: hidden;
    }
    .div-43 {
      color: var(--TextColor, #333);
      margin-top: 8px;
      white-space: nowrap;
      font: 500 16px/125% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-43 {
        white-space: initial;
      }
    }
    .div-44 {
      justify-content: space-between;
      align-self: stretch;
      display: flex;
      margin-top: 16px;
      padding-left: 80px;
      gap: 20px;
    }
    @media (max-width: 991px) {
      .div-44 {
        max-width: 100%;
        flex-wrap: wrap;
        padding-left: 20px;
      }
    }
    .div-45 {
      color: var(--gray-400, #9ca3af);
      white-space: nowrap;
      justify-content: center;
      border-radius: 100px;
      border: 1px solid var(--gray-400, #9ca3af);
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
      background-color: var(--white, #fff);
      flex-grow: 1;
      padding: 9px 40px;
      font: 500 16px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-45 {
        white-space: initial;
        padding: 0 20px;
      }
    }
    .div-46 {
      color: var(--Whitee, #fff);
      white-space: nowrap;
      justify-content: center;
      border-radius: 100px;
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
      background-color: var(--Green, #24a86a);
      flex-grow: 1;
      padding: 9px 41px;
      font: 500 16px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-46 {
        white-space: initial;
        padding: 0 20px;
      }
    }
    
  </style>
  